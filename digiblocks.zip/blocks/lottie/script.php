<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// This file exists to ensure the lottie block generates a JS file
// which triggers the global asset loading (lottie.js)
// The actual lottie functionality is handled by the global lottie.js script

$digiblocks_js_output = '/* Lottie block placeholder */';