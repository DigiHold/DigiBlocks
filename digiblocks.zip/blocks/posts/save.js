/**
 * Save function for the Post block
 */
const PostsSave = () => {
    // Since we're using server-side rendering,
    // we don't need to render anything here
    return null;
};

export default PostsSave;