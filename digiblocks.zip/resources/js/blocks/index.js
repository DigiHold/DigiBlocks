/**
 * Auto-generated imports for all blocks
 * Total blocks: 27
 */
import '../../../blocks/container/index.js';
import '../../../blocks/accordion/index.js';
import '../../../blocks/button/index.js';
import '../../../blocks/buttons/index.js';
import '../../../blocks/call-to-action/index.js';
import '../../../blocks/column/index.js';
import '../../../blocks/countdown/index.js';
import '../../../blocks/counter/index.js';
import '../../../blocks/faq/index.js';
import '../../../blocks/forms/index.js';
import '../../../blocks/google-map/index.js';
import '../../../blocks/heading/index.js';
import '../../../blocks/icon/index.js';
import '../../../blocks/icon-box/index.js';
import '../../../blocks/icon-list/index.js';
import '../../../blocks/image/index.js';
import '../../../blocks/lottie/index.js';
import '../../../blocks/newsletter/index.js';
import '../../../blocks/posts/index.js';
import '../../../blocks/pricing-table/index.js';
import '../../../blocks/separator/index.js';
import '../../../blocks/social-icons/index.js';
import '../../../blocks/spacer/index.js';
import '../../../blocks/table/index.js';
import '../../../blocks/team/index.js';
import '../../../blocks/testimonials/index.js';
import '../../../blocks/text/index.js';
